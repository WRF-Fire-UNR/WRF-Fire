.. _ubuntu:

==================================================================
How to automatically compile WRF-Fire on Ubuntu using shell script
==================================================================

.. note::
  
   This page is under construction