.. _compileWin:

==================================
How to compile WRF-Fire on Windows
==================================

.. note::
  
   This page is under construction 
