=====================
FAQ and Common Issues
=====================
FAQ regarding downloading, installing, and using WRF-Fire, creating the input files, visualization
Common issues when compiling and running WRF, and visualization